# Little Lemon Table Booking App

This React app allows users to reserve a table at the Little Lemon restaurant.

## Features
- Booking form with date, time, guests, and personal details.
- Client-side validation with helpful error messages.
- Responsive design (mobile/desktop).
- Unit tests for critical components.

## Setup and run

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/little-lemon-booking.git
   cd little-lemon-booking
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the development server:
   ```bash
   npm start
   ```
   Open [http://localhost:3000](http://localhost:3000)

4. Run tests:
   ```bash
   npm test
   ```

## Project structure
- `src/components/BookingForm.js` – main booking form with validation.
- `src/components/Confirmation.js` – confirmation screen after successful booking.
- `src/tests/BookingForm.test.js` – unit tests.

## Assumptions
- No backend API is used; booking data is only logged and shows a confirmation.
- Date picker prevents past dates.
- Email format is validated.

## License
MIT
