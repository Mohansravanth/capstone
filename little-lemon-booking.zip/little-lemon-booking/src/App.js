import React, { useState } from 'react';
import './App.css';
import BookingForm from './components/BookingForm';
import Confirmation from './components/Confirmation';

function App() {
  const [submitted, setSubmitted] = useState(false);
  const [bookingData, setBookingData] = useState(null);

  const handleBookingSubmit = (data) => {
    setBookingData(data);
    setSubmitted(true);
  };

  return (
    <div className="App">
      <header className="app-header">
        <img src="https://via.placeholder.com/150x50?text=Little+Lemon" alt="Little Lemon logo" />
        <h1>Reserve a Table</h1>
      </header>
      <main>
        {!submitted ? (
          <BookingForm onSubmit={handleBookingSubmit} />
        ) : (
          <Confirmation bookingData={bookingData} />
        )}
      </main>
    </div>
  );
}

export default App;
