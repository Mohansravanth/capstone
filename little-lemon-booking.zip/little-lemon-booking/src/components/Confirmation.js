import React from 'react';

const Confirmation = ({ bookingData }) => {
  return (
    <div className="confirmation" style={{ textAlign: 'center', padding: '2rem' }}>
      <h2>Booking confirmed! 🎉</h2>
      <p>Thank you, {bookingData.firstName} {bookingData.lastName}.</p>
      <p>Your table for {bookingData.guests} guest(s) on {bookingData.date} at {bookingData.time} is reserved.</p>
      <p>A confirmation email has been sent to {bookingData.email}.</p>
    </div>
  );
};

export default Confirmation;
