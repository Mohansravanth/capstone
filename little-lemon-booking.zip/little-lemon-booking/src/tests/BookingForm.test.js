import { render, screen, fireEvent } from '@testing-library/react';
import BookingForm from '../components/BookingForm';

test('renders booking form with all fields', () => {
  render(<BookingForm onSubmit={() => {}} />);
  expect(screen.getByLabelText(/Date/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/Time/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/Number of guests/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/First name/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/Last name/i)).toBeInTheDocument();
  expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
});

test('shows validation errors when required fields are empty', async () => {
  render(<BookingForm onSubmit={() => {}} />);
  fireEvent.click(screen.getByText(/Confirm reservation/i));
  expect(await screen.findByText(/First name is required/i)).toBeInTheDocument();
  expect(await screen.findByText(/Last name is required/i)).toBeInTheDocument();
  expect(await screen.findByText(/Email is required/i)).toBeInTheDocument();
});

test('submit is only called when all fields are valid', () => {
  const mockSubmit = jest.fn();
  render(<BookingForm onSubmit={mockSubmit} />);

  fireEvent.change(screen.getByLabelText(/First name/i), { target: { value: 'John' } });
  fireEvent.change(screen.getByLabelText(/Last name/i), { target: { value: 'Doe' } });
  fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'john@example.com' } });
  fireEvent.click(screen.getByText(/Confirm reservation/i));

  expect(mockSubmit).toHaveBeenCalledTimes(1);
});
